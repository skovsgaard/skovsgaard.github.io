import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 
import ddf.minim.analysis.*; 
import ddf.minim.effects.*; 
import ddf.minim.signals.*; 
import ddf.minim.spi.*; 
import ddf.minim.ugens.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class verticaljumper_4 extends PApplet {








player p1;
obstacle[] hearts = new obstacle[650];
canvas b1;
score score;

PImage heart;
PImage bgBot;
PImage bgTop;

float cameraY = 0;
int cameraUpdate = 0;
int timeStart = 0;

Minim jumper1;
Minim jumper2;
Minim jumper3;
Minim bg_music;
AudioPlayer jump1;
AudioPlayer jump2;
AudioPlayer jump3;

AudioPlayer bgMusicPlayer;

public void setup() {
  frameRate(60);
  

  jumper1 = new Minim(this);
  jumper2 = new Minim(this);
  jumper3 = new Minim(this);
  bg_music = new Minim(this);
  jump1 = jumper1.loadFile("jump.mp3");
  jump2 = jumper2.loadFile("jump.mp3");
  jump3 = jumper3.loadFile("jump.mp3");
  bgMusicPlayer = bg_music.loadFile("bgMusic.mp3");
  bgMusicPlayer.loop();

  heart = loadImage("data/heart.png");
  heart.resize(40, 0);
  bgBot = loadImage("data/bg_bottom.png");
  bgBot.resize(750, 0);
  bgTop = loadImage("data/bg_top.png");
  bgTop.resize(750, 0);

  score = new score();
  p1 = new player();
  b1 = new canvas();

  hearts[0] = new obstacle(200, 100);
  hearts[1] = new obstacle(600, 150);

  for (int i = 2; i < 600; i++) {
    hearts[i] = new obstacle(PApplet.parseInt(random(100, 650)), (i*-400) + 500);
  }

  for (int i = 600; i < 630; i++) {
    hearts[i] = new obstacle(PApplet.parseInt(random(100, 650)), ((i - 600)* -400) + 300);
  }

  for (int i = 630; i < hearts.length; i++) {
    hearts[i] = new obstacle(PApplet.parseInt(random(100, 650)), ((i - 630)* -400) + 400);
  }
}

public void draw() {

  background(255);

  pushMatrix();
  translate(0, cameraY);
  b1.display();
  for (int i = 0; i < hearts.length; i++) {
    if (hearts[i].obstacleAlive == true) {
      hearts[i].display();
    } else {
      hearts[i] = new obstacle(-100, -100);
    }
  }
  p1.display();
  popMatrix();

  score.display();
  score.addScore();
  p1.move();
  p1.jumpTimer();
  p1.sendPlayerPos();

  if (p1.posY < height / 2) {
    cameraY = height/2 - p1.posY;
  }
  if (p1.playerAlive == true) {
    timeStart = millis();
    if (pressedSpace == true) {
      reset();
    }
  } else {
    int time = millis() - timeStart;
    if (time > 1000) {
      score.scoreBoard();
      if (pressedSpace == true) {
        reset();
      }
    }
  }
}

public void reset() {
  p1.posY = height - (p1.verSize * 0.5f);
  p1.playerAlive = true;
  score.score = 0;
  p1.initState = true;
  p1.scoreToAdd = 10;
  p1.playerScore = 0;
  cameraY = 0;
  for (int i = 2; i < 600; i++) {
    hearts[i] = new obstacle(PApplet.parseInt(random(100, 650)), (i*-400) + 500);
  }

  for (int i = 600; i < 630; i++) {
    hearts[i] = new obstacle(PApplet.parseInt(random(100, 650)), ((i - 600)* -400) + 300);
  }

  for (int i = 630; i < hearts.length; i++) {
    hearts[i] = new obstacle(PApplet.parseInt(random(100, 650)), ((i - 630)* -400) + 400);
  }
}
class canvas {
  int initYbot = -736;
  int initYtop = -1972;
  int yBot = initYbot;
  int yTop = initYtop;

  public void display() {
    image(bgBot, 0, yBot);
    image(bgTop, 0, yTop);

    if (p1.posY < yBot - 300) {
      yBot -= 2472;
    } else if (p1.posY > yBot + 1236 + 300) {
      yBot += 2472;
    }

    if (p1.posY < yTop - 300) {
      yTop -= 2472;
    } else if (p1.posY > yTop + 1236 + 300) {
      yTop += 2472;
    }
  }
}
boolean pressedLeft = false;
boolean playerJump = false;
boolean pressedSpace = false;

public void mousePressed() {
  if (mouseButton == LEFT) {
    pressedLeft = true;
    playerJump = true;
  }
}

public void mouseReleased() {
  if (mouseButton == LEFT) {
    pressedLeft = false;
  }
}

public void keyPressed() {
  if ( key == ' ') {
    pressedSpace = true;
  }
}

public void keyReleased() {
  if (key == ' ') {
    pressedSpace = false;
  }
}
class obstacle {
  float posX;
  float posY;
  float initPosY;

  int obstacleSize = 40;
  boolean obstacleAlive = true;

  obstacle(int x, int y) {
    posX = x;
    posY = y;
    initPosY = y;
  }

  public void display() {
    image(heart, posX, posY);
  }

  public void playerCollision(float playerX, float playerY) {
    if (p1.jumping == false) {
      if ((playerX < (posX + obstacleSize)) &&
        (playerX > posX ) &&
        (playerY < (posY + obstacleSize)) &&
        (playerY > posY)) {
        p1.jumping = true;
        obstacleAlive = false;

        jump1.rewind();
        jump1.play();
      }
    }
  }
}
class player {
  int verSize = 50;
  int horSize = 50;

  float posX = 400;
  float posY = height - (verSize * 0.5f);

  int iTicksLastUpdate = 0;
  int playerSpeed = 0;
  float gravity = 0;

  boolean checkCollision = true;
  boolean jumping = false;
  int jumpOnce = 0;
  int jumpSound = 0;

  int timerStart = 0;
  long playerScore = 0;
  long scoreToAdd = 10;

  boolean playerAlive = true;
  boolean initState = true;

  public void display() {
    fill(255);
    ellipse(posX, posY, verSize, horSize);
  }

  public void move() {
    posX = constrain(mouseX, 0 + (horSize * 0.5f), width - (horSize * 0.5f));
    posY -= playerSpeed - gravity * PApplet.parseFloat(millis() - iTicksLastUpdate) * 0.01f;
    iTicksLastUpdate = millis();

    if (playerSpeed > 0) {
      gravity = 0;
      playerSpeed -= 3;
    } else {
      gravity += 2;
    }

    if ((posY >= height - horSize) && (initState == true)) {
      if (playerJump) {
        initState = false;
        playerSpeed += 50;
        playerJump = false;
      }
    } else if ((posY > height) && (initState == false)) {
      playerAlive = false;
    }


    obstacleJump();

    if (posY >= height - (verSize * 0.5f)) {
      posY = height - (verSize * 0.5f);
    }
  }

  public void obstacleJump() {
    if (jumping == true) {
      if (jumpOnce == 0) {
        playerScore += scoreToAdd;
        scoreToAdd += 10;

        playerSpeed = 50;
        jumpOnce = 1;
      }
    }
  }

  public void jumpTimer() {
    if (jumping == false) {
      timerStart = millis();
    } else {
      int time = millis () - timerStart;
      if (time >= 100) {
        jumping = false;
        jumpOnce = 0;
      }
    }
  }

  public void sendPlayerPos() {
    for (int i = 0; i < hearts.length; i ++) {
      hearts[i].playerCollision(posX, posY);
    }
  }
}
class score {
  long score = 0;

  public void display() {
    if (p1.playerAlive == true) {
      textSize(20);
      text("Score: " + score, 5, 20);
    }
  }

  public void addScore() {    
    score = p1.playerScore;
  }

  public void scoreBoard() {
    fill(0);
    //rectMode(CENTER);
    rect(0, 0, width, height);
    fill(255);
    text("You scored ", 325, 220);
    text((int)score + " !!!!", width * 0.5f - 15, height * 0.5f + 20);
    text("Great job!", 325, height * 0.5f + 60);
  }
}
  public void settings() {  size(750, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "verticaljumper_4" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
